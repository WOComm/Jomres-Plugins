This plugin runs automatically in the background and sends a reminder email to guests to leave a review after a number of days from their departure date.
