<?php
/**
* Jomres CMS Agnostic Plugin
* @author Woollyinwales IT <sales@jomres.net>
* @version Jomres 9 
* @package Jomres
* @copyright	2005-2016 Woollyinwales IT
* Jomres (tm) PHP files are released under both MIT and GPL2 licenses. This means that you can choose the license that best suits your project.
**/

// ################################################################
defined( '_JOMRES_INITCHECK' ) or die( '' );
// ################################################################

	jr_define('REST_API_ACCESS_TOKENS_MENU_OPTION',"Elenca token di accesso API REST");
	jr_define('REST_API_ACCESS_TOKENS_INFO',"Questa pagina elenca tutti i client e, se disponibili, i loro token di accesso (i client potrebbero non aver richiesto un token di accesso). Ciò è utile se desideri inviare query tramite un client come Postman e hai bisogno di un token di accesso Sebbene questa pagina elenchi i token di accesso al SISTEMA, non è consigliabile utilizzarli. ");
