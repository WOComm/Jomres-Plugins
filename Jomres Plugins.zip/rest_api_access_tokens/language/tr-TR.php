<?php
/**
 * Core file.
 *
 * @author Vince Wooll <sales@jomres.net>
 *
 * @version Jomres 9.24.0
 *
 * @copyright	2005-2021 Vince Wooll
 * Jomres (tm) PHP, CSS & Javascript files are released under both MIT and GPL2 licenses. This means that you can choose the license that best suits your project, and use it accordingly
 **/
//#################################################################
defined('_JOMRES_INITCHECK') or die('');
//#################################################################

	jr_define('REST_API_ACCESS_TOKENS_MENU_OPTION',"REST API Erişim belirteçlerini listele");
	jr_define('REST_API_ACCESS_TOKENS_INFO',"Bu sayfada tüm istemciler ve varsa erişim belirteçleri listelenir (istemciler bir erişim belirteci istememiş olabilir). Postacı gibi bir istemci aracılığıyla sorgu göndermek istiyorsanız ve bir erişim belirtecine ihtiyacınız varsa bu kullanışlıdır . Bu sayfada SİSTEM erişim belirteçleri listelense de, bunları kullanmanız önerilmez. ");