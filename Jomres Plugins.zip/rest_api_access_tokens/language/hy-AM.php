<?php
/**
 * Core file.
 *
 * @author Vince Wooll <sales@jomres.net>
 *
 * @version Jomres 9.24.0
 *
 * @copyright	2005-2021 Vince Wooll
 * Jomres is currently available for use in all personal or commercial projects under both MIT and GPL2 licenses. This means that you can choose the license that best suits your project, and use it accordingly
 **/
//#################################################################
defined('_JOMRES_INITCHECK') or die('');
//#################################################################
	jr_define('REST_API_ACCESS_TOKENS_MENU_OPTION',"Ցուցակել REST API-ի հասանելիության նշանները");
	jr_define('REST_API_ACCESS_TOKENS_INFO',"Այս էջը թվարկում է բոլոր հաճախորդները և առկայության դեպքում՝ նրանց մուտքի նշանները (հաճախորդները կարող են մուտքի նշան չպահանջել): Սա օգտակար է, եթե ցանկանում եք հարցումներ ուղարկել այնպիսի հաճախորդի միջոցով, ինչպիսին Փոստատարն է, և Ձեզ անհրաժեշտ է մուտքի նշան: Չնայած այս էջը թվարկում է SYSTEM մուտքի նշաններ, խորհուրդ չի տրվում օգտագործել դրանք: ");