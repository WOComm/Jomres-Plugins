<?php
/**
 * Core file.
 *
 * @author Vince Wooll <sales@jomres.net>
 *
 * @version Jomres 9.24.0
 *
 * @copyright	2005-2021 Vince Wooll
 * Jomres is currently available for use in all personal or commercial projects under both MIT and GPL2 licenses. This means that you can choose the license that best suits your project, and use it accordingly
 **/
//#################################################################
defined('_JOMRES_INITCHECK') or die('');
//#################################################################
	jr_define('REST_API_ACCESS_TOKENS_MENU_OPTION',"Λίστα κουπονιών πρόσβασης REST API");
jr_define('REST_API_ACCESS_TOKENS_INFO',"Αυτή η σελίδα παραθέτει όλους τους πελάτες και, εάν είναι διαθέσιμα, τα διακριτικά πρόσβασής τους (οι πελάτες μπορεί να μην έχουν ζητήσει διακριτικό πρόσβασης). Αυτό είναι χρήσιμο εάν θέλετε να στείλετε ερωτήματα μέσω ενός πελάτη όπως ο Ταχυδρόμος και χρειάζεστε ένα διακριτικό πρόσβασης Παρόλο που αυτή η σελίδα παραθέτει τα διακριτικά πρόσβασης SYSTEM, δεν συνιστάται η χρήση τους. ");