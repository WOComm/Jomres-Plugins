Pulls a random review from the database, quote the review, output it's score and provide a link to the property.

See the shortcodes page for more information.