Adds new buttons that open up modals for quick registration and login.

{{modal_register.png}}

{{modal_login.png}}

By default, the plugin is enabled, which means that it will show these buttons above the Jomres content area. 

{{above_content_area.png}}

In the Administrator > Jomres > Settings > Site Configuration > Portal functionality tab you can enable/disable this behaviour. 

{{portal_tab.png}}

You can choose to disable the appearance above the content area, using this option. The quick_register task however is still available, so instead you can use a shortcode to place the Quick Register buttons somewhere else.

